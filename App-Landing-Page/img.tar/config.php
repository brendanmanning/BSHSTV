<?php
	define("EMAIL", "appsupport@brendanmanning.com");