<?php
// show potential errors / feedback (from registration object)
if (isset($registration)) {
    if ($registration->errors) {
        foreach ($registration->errors as $error) {
            echo $error;
        }
    }
    if ($registration->messages) {
        foreach ($registration->messages as $message) {
            echo $message;
        }
    }
}
?>
<?php
	require '../config.php';
	$conn = new PDO("mysql:host=" . $host . ";dbname=" . $name,$user,$pass);
	$sql = $conn->prepare("SELECT user_name,email FROM teachertokens WHERE token LIKE :tok");
	$sql->bindParam(":tok", $_GET['token']);


	$username = "";
	$email = "";
    	// Run the query and get the results
    	$sql->execute();
    	while($row=$sql->fetch()) {
    		$username = $row['user_name'];
    		$email = $row['email'];
    	}
    	
?>
<!-- register form -->
<form method="post" action="register.php" name="registerform">

    <!-- the user name input field uses a HTML5 pattern check -->
    <label for="login_input_username">Username (only letters and numbers, 2 to 64 characters)</label>
    <input id="login_input_username" class="login_input" type="text" pattern="[a-zA-Z0-9]{2,64}" name="user_name" value=<?php echo '"' . $username . '"'; if($username != "") { echo 'readOnly="readOnly"'; } ?> required />

    <!-- the email input field uses a HTML5 email type check -->
    <label for="login_input_email">User's email</label>
    <input id="login_input_email" class="login_input" type="email" name="user_email" value=<?php echo '"' . $email . '"'; if($email != "") { echo 'readOnly="readOnly"'; }?> required />
	
    <label for="login_input_password_new">Password (min. 6 characters)</label>
    <input id="login_input_password_new" class="login_input" type="password" name="user_password_new" pattern=".{6,}" value=<?php if($username!="") { echo '"notrequired" readOnly="readOnly"'; } ?> required autocomplete="off" />

    <label for="login_input_password_repeat">Repeat password</label>
    <input id="login_input_password_repeat" class="login_input" type="password" name="user_password_repeat" pattern=".{6,}" value=<?php if($username!="") { echo '"notrequired" readOnly="readOnly"'; } ?> required autocomplete="off" />
    <input type="hidden" name="token" value=<?php if(isset($_GET['token'])){echo '"' . $_GET['token'] . '"';} else { echo '""'; }?>>
    	
    <input type="submit"  name="register" value="Register" />

</form>

<!-- backlink -->
<a href="index.php">Back to Login Page</a>