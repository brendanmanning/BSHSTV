function showSports()
{
	document.getElementById("sportsDiv").visibility = 'visible';
	document.getElementById("hasSports").value = "yes";
}

function hideSports()
{
	document.getElementById("sportsDiv").visibility = 'hidden';
	document.getElementById("hasSports").value = "no";
}