<?php
	include 'auth.php';
?>

<html>
	<head>
		<title>Add a Club</title>
		<link rel="stylesheet" href="mainstyle.css" />
	</head>
	
	<body>
		<h1>Add a 